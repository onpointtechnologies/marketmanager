 <div class="row align-items-center justify-content-between d-flex">
      <div id="logo">
        <a href="index.html"><img src="img/logo.png" width: "50" height: "50" alt="" title="" /></a>
      </div>
      <nav id="nav-menu-container" >
         <ul class="nav-menu">
                  <li class="menu-active" style="background:#cccccc; border-radius: 10%;"><a href="index.php">Home</a></li>
                  <li style="background:#cccccc; border-radius: 10%;"><a href="#feature">Features</a></li>
                  <li style="background:#cccccc; border-radius: 10%;"><a href="#price">Price</a></li>
                  <li class="#" style="background:#cccccc; border-radius: 10%;"><a href="#">Contact</a></li>
                  <li><a class="ticker-btn btn-md" href="sign-in.php">Login</a></li>
                  <li class="menu-has-children"><a class="ticker-btn" href="#">Sign Up</a>
		              <ul>
		                <li><a href="registerFarmer.php">Farmer Registration</a></li>
		                <li><a href="registerWholesaler.php">Wholesaler Registration</a></li>
		              </ul>
		            </li>
                </ul>
      </nav><!-- #nav-menu-container -->
    </div>