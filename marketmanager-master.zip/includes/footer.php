</div>

<!-- start footer Area -->
<footer class="footer-area section-gap navbar-fixed-bottom">

    <div class="row row_footer">
      <div class="col-md-2">
      </div>
      <div class="col-md-8">
        <div class="single-footer-widget">
          <p class="p_footer">
            <!-- We love farmers and technology and thought their must be an easier way to combine them, so we built Market Manager! -->
            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Market Manager V1.0
          </p>
          <p class="p_footer">
              <!-- Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Market Manager &copy 2018 -->
          </p>
        </div>
      </div>
      <div class="col-md-2">
      </div>
    </div>
</footer>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="js/metisMenu/metisMenu.min.js"></script>




    <!-- Custom Theme JavaScript -->
    <script src="js/sb-admin-2.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/sumTable.js"></script>



</body>

</html>
